import{_ as t}from"./about-project.vue_vue_type_script_setup_true_lang-CbhYJOLW.js";import"./index-BA_QZ57a.js";export{t as default};
