import{bN as s}from"./index-TJq2kz6j.js";const i=i=>["",...s].includes(i);export{i};
