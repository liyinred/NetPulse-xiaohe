import{_ as t}from"./dynamic-stats.vue_vue_type_script_setup_true_lang-LeAc-71u.js";import"./index-ZO7WVn61.js";/* empty css                     */import"./index-SdL_NDt7.js";export{t as default};
