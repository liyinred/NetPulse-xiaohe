import{_ as t}from"./about-project.vue_vue_type_script_setup_true_lang-SLHUevrR.js";import"./index-ZO7WVn61.js";export{t as default};
