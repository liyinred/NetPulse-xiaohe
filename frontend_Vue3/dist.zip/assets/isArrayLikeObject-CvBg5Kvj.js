import{dw as s,dx as a,dv as n,cb as r,cU as t}from"./index-BiOLqZhS.js";function i(r,t){return s(a(r,t,n),r+"")}function o(s){return r(s)&&t(s)}export{i as b,o as i};
