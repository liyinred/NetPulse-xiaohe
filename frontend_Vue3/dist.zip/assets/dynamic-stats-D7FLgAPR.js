import{_ as t}from"./dynamic-stats.vue_vue_type_script_setup_true_lang-QUyfmVj6.js";import"./index-BUpMu0LD.js";/* empty css                     */import"./index-DEdafeof.js";export{t as default};
