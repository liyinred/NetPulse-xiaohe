import{_ as t}from"./about-project.vue_vue_type_script_setup_true_lang-l0YnSrFL.js";import"./index-Df-iA6-7.js";export{t as default};
