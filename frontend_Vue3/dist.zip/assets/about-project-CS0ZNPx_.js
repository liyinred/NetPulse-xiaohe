import{_ as t}from"./about-project.vue_vue_type_script_setup_true_lang-C16-5rvl.js";import"./index-BEKtGHCw.js";export{t as default};
