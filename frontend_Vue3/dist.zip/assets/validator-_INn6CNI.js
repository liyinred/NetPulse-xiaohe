import{bN as s}from"./index-BBNPh6Bj.js";const i=i=>["",...s].includes(i);export{i};
