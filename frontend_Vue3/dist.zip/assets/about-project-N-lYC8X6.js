import{_ as t}from"./about-project.vue_vue_type_script_setup_true_lang-Bqc_YDVY.js";import"./index-CmnCCfS5.js";export{t as default};
