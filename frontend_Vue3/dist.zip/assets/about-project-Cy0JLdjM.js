import{_ as t}from"./about-project.vue_vue_type_script_setup_true_lang-Dipi9VNU.js";import"./index-BUpMu0LD.js";export{t as default};
