import{_ as t}from"./about-project.vue_vue_type_script_setup_true_lang-CzxlKRR4.js";import"./index-Bi308adM.js";export{t as default};
