import{_ as t}from"./about-project.vue_vue_type_script_setup_true_lang-Wkz4cFZt.js";import"./index-DAy5iqTJ.js";export{t as default};
