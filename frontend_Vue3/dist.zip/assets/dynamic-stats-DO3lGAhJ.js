import{_ as t}from"./dynamic-stats.vue_vue_type_script_setup_true_lang-DtXiKcaJ.js";import"./index-DthvOXIe.js";/* empty css                     */import"./index-COV5OYfQ.js";export{t as default};
