import{dw as s,dx as a,dv as n,cc as r,cV as t}from"./index-TJq2kz6j.js";function c(r,t){return s(a(r,t,n),r+"")}function i(s){return r(s)&&t(s)}export{c as b,i};
