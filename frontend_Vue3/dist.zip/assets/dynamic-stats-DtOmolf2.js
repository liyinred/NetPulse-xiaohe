import{_ as t}from"./dynamic-stats.vue_vue_type_script_setup_true_lang-CLtxPNZ2.js";import"./index-BEKtGHCw.js";/* empty css                     */import"./index-BGjmrfrn.js";export{t as default};
