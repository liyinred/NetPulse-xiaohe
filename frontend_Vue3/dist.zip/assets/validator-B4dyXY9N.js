import{bA as s}from"./index-DhC3D6qo.js";const i=i=>["",...s].includes(i);export{i};
