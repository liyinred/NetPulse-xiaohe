import{_ as t}from"./dynamic-stats.vue_vue_type_script_setup_true_lang-CGDsEsmV.js";import"./index-CYo4iZoO.js";/* empty css                     */import"./index-CEf_MZcg.js";export{t as default};
