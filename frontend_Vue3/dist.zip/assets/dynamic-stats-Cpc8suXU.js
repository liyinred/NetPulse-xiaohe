import{_ as t}from"./dynamic-stats.vue_vue_type_script_setup_true_lang-9V6Fnpux.js";import"./index-xzeEeakU.js";/* empty css                     */import"./index-rBkGlZSo.js";export{t as default};
