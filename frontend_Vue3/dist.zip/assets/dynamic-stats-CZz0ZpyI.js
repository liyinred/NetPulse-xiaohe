import{_ as t}from"./dynamic-stats.vue_vue_type_script_setup_true_lang-DGNadWs3.js";import"./index-Df-iA6-7.js";/* empty css                     */import"./index-DhstNC-j.js";export{t as default};
