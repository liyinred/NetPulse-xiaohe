import{_ as t}from"./about-project.vue_vue_type_script_setup_true_lang-0dG1AOcU.js";import"./index-DhC3D6qo.js";export{t as default};
