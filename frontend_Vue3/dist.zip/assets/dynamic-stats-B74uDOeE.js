import{_ as t}from"./dynamic-stats.vue_vue_type_script_setup_true_lang-lAQdWOSN.js";import"./index-BiOLqZhS.js";/* empty css                     */import"./index-BYFevO3M.js";export{t as default};
