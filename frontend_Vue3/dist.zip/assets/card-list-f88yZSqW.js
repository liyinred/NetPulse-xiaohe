import{_ as t}from"./card-list.vue_vue_type_script_setup_true_lang-bQhLrFeF.js";import"./index-CYo4iZoO.js";import"./el-row-8qY8_0Zw.js";import"./el-col-DTGPtoAB.js";export{t as default};
