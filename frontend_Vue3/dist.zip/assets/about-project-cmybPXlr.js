import{_ as t}from"./about-project.vue_vue_type_script_setup_true_lang-CNRTWmOd.js";import"./index-xzeEeakU.js";export{t as default};
