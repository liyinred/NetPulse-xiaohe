const a="/user_avatar.png";export{a as _};
