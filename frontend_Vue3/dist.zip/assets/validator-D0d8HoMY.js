import{bI as s}from"./index-BEKtGHCw.js";const i=i=>["",...s].includes(i);export{i};
