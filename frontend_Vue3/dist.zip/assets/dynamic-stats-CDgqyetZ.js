import{_ as t}from"./dynamic-stats.vue_vue_type_script_setup_true_lang-C7ZsLioZ.js";import"./index-C82J0UZU.js";/* empty css                     */import"./index-BUS6rJAh.js";export{t as default};
