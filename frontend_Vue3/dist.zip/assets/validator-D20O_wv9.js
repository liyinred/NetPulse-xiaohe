import{bM as s}from"./index-BZuQvp4X.js";const i=i=>["",...s].includes(i);export{i};
