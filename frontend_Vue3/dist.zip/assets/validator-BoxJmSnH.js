import{bM as s}from"./index-BiOLqZhS.js";const i=i=>["",...s].includes(i);export{i};
