import{bI as s}from"./index-CYo4iZoO.js";const i=i=>["",...s].includes(i);export{i};
