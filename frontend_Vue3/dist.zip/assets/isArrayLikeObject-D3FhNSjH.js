import{dv as s,dw as a,du as n,cv as r,cs as t}from"./index-BUpMu0LD.js";function i(r,t){return s(a(r,t,n),r+"")}function o(s){return r(s)&&t(s)}export{i as b,o as i};
