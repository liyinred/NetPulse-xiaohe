import{bM as s}from"./index-CMx2f2jv.js";const i=i=>["",...s].includes(i);export{i};
