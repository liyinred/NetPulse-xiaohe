import{_ as t}from"./about-project.vue_vue_type_script_setup_true_lang-iNFDOGPH.js";import"./index-BiOLqZhS.js";export{t as default};
