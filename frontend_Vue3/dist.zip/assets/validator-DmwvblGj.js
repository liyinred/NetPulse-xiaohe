import{bM as s}from"./index-CmnCCfS5.js";const i=i=>["",...s].includes(i);export{i};
