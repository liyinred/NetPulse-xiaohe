import{_ as t}from"./dynamic-stats.vue_vue_type_script_setup_true_lang-CC4iBDXz.js";import"./index-BA_QZ57a.js";/* empty css                     */import"./index-DjFImfDJ.js";export{t as default};
