import{_ as t}from"./about-project.vue_vue_type_script_setup_true_lang-ompdUAgO.js";import"./index-BZuQvp4X.js";export{t as default};
