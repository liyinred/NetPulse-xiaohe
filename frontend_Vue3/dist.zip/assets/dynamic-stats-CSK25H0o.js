import{_ as t}from"./dynamic-stats.vue_vue_type_script_setup_true_lang-Bz2TVy2A.js";import"./index-BBNPh6Bj.js";/* empty css                     */import"./index-CoOIEFlh.js";export{t as default};
