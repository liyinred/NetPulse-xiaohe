import{_ as t}from"./about-project.vue_vue_type_script_setup_true_lang-BNaSEFRO.js";import"./index-CC0IAAuy.js";export{t as default};
