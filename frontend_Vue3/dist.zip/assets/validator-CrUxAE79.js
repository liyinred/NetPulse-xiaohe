import{bI as s}from"./index-DthvOXIe.js";const i=i=>["",...s].includes(i);export{i};
