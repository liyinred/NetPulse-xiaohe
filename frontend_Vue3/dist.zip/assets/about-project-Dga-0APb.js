import{_ as t}from"./about-project.vue_vue_type_script_setup_true_lang-CCzlmlK1.js";import"./index-C82J0UZU.js";export{t as default};
