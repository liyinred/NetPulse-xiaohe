import{_ as t}from"./about-project.vue_vue_type_script_setup_true_lang-BAbAuxgF.js";import"./index-CYo4iZoO.js";export{t as default};
