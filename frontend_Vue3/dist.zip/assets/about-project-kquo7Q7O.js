import{_ as t}from"./about-project.vue_vue_type_script_setup_true_lang-8CeRF3Zf.js";import"./index-BBNPh6Bj.js";export{t as default};
