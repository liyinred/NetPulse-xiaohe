import{dy as s,dz as a,dx as n,cc as r,cX as t}from"./index-C82J0UZU.js";function c(r,t){return s(a(r,t,n),r+"")}function i(s){return r(s)&&t(s)}export{c as b,i};
