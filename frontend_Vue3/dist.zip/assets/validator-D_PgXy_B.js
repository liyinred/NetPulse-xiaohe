import{bM as s}from"./index-BA_QZ57a.js";const i=i=>["",...s].includes(i);export{i};
