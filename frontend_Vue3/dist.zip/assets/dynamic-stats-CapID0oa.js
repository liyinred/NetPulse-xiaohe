import{_ as t}from"./dynamic-stats.vue_vue_type_script_setup_true_lang-BGYL9Z00.js";import"./index-DVR9lVtL.js";import"./index-DhC3D6qo.js";/* empty css                     */export{t as default};
