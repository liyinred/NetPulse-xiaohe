import{ds as s,dt as n,dr as r,cq as a,cn as t}from"./index-Df-iA6-7.js";function i(a,t){return s(n(a,t,r),a+"")}function o(s){return a(s)&&t(s)}export{i as b,o as i};
