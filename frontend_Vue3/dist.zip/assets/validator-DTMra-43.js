import{bN as s}from"./index-Bi308adM.js";const i=i=>["",...s].includes(i);export{i};
