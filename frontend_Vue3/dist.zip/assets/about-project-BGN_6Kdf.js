import{_ as t}from"./about-project.vue_vue_type_script_setup_true_lang-cNf59WKE.js";import"./index-TJq2kz6j.js";export{t as default};
