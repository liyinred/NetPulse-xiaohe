import{_ as t}from"./dynamic-stats.vue_vue_type_script_setup_true_lang-Uc9MK93S.js";import"./index-Bi308adM.js";/* empty css                     */import"./index-EnqjDn3J.js";export{t as default};
