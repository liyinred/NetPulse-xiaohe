import{bN as s}from"./index-C82J0UZU.js";const i=i=>["",...s].includes(i);export{i};
