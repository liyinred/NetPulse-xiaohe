import{bI as s}from"./index-Df-iA6-7.js";const i=i=>["",...s].includes(i);export{i};
