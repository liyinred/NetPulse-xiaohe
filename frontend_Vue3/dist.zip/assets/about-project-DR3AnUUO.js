import{_ as t}from"./about-project.vue_vue_type_script_setup_true_lang-D0JMZflD.js";import"./index-DthvOXIe.js";export{t as default};
