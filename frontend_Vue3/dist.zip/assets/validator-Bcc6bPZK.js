import{bM as s}from"./index-DAy5iqTJ.js";const i=i=>["",...s].includes(i);export{i};
