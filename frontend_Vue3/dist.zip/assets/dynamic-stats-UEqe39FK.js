import{_ as t}from"./dynamic-stats.vue_vue_type_script_setup_true_lang-_WTduVp3.js";import"./index-BZuQvp4X.js";/* empty css                     */import"./index-DTQ_VTXN.js";export{t as default};
