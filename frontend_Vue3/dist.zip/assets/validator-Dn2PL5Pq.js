import{bM as s}from"./index-ZO7WVn61.js";const i=i=>["",...s].includes(i);export{i};
