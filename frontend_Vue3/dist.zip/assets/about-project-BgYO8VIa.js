import{_ as t}from"./about-project.vue_vue_type_script_setup_true_lang-0GfcACPF.js";import"./index-CMx2f2jv.js";export{t as default};
