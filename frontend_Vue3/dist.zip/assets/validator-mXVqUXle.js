import{bG as s}from"./index-BUpMu0LD.js";const i=i=>["",...s].includes(i);export{i};
