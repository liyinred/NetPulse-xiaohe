import{_ as t}from"./dynamic-stats.vue_vue_type_script_setup_true_lang-cROeusJU.js";import"./index-CC0IAAuy.js";/* empty css                     */import"./index-DEo_S6t7.js";export{t as default};
