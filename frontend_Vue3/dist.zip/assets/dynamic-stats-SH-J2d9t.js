import{_ as t}from"./dynamic-stats.vue_vue_type_script_setup_true_lang-atIsBMHo.js";import"./index-CMx2f2jv.js";/* empty css                     */import"./index-BjuyPQKN.js";export{t as default};
