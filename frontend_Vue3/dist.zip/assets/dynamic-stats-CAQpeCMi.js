import{_ as t}from"./dynamic-stats.vue_vue_type_script_setup_true_lang-B-Wu_d1Y.js";import"./index-DAy5iqTJ.js";/* empty css                     */import"./index-DcYD7mUP.js";export{t as default};
