import{_ as t}from"./dynamic-stats.vue_vue_type_script_setup_true_lang-D5e-fYU1.js";import"./index-TJq2kz6j.js";/* empty css                     */import"./index-ewRmJULb.js";export{t as default};
