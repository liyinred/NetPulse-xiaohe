import{bM as s}from"./index-xzeEeakU.js";const i=i=>["",...s].includes(i);export{i};
