import{bM as s}from"./index-CC0IAAuy.js";const i=i=>["",...s].includes(i);export{i};
