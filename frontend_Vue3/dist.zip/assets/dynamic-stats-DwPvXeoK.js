import{_ as t}from"./dynamic-stats.vue_vue_type_script_setup_true_lang-Bq4mDm6s.js";import"./index-CmnCCfS5.js";/* empty css                     */import"./index-C3A9PxTj.js";export{t as default};
